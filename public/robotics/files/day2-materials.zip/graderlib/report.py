"""计分与报告输出。

不依赖 rclpy，可在任意机器上单测。所有 grade_dayN.py 都用这两个类型汇报结果。

设计原则：**失败时必须告诉学员期望什么、实际测到什么、建议怎么查。**
只输出"扣了 20 分"对一个没人可问的自学学员毫无用处。
"""
import json
from dataclasses import dataclass, field
from typing import List, Optional

# 终端颜色。调用方可用 render_terminal(color=False) 关掉。
_GREEN, _RED, _YELLOW, _DIM, _RESET = "\033[32m", "\033[31m", "\033[33m", "\033[2m", "\033[0m"


@dataclass
class CheckResult:
    """单个检查项的结果。

    points 留空时按 passed 取 max_points 或 0；需要给部分分时显式传入。
    """

    name: str
    max_points: float
    passed: bool
    expected: str
    actual: str
    hint: str = ""
    points: Optional[float] = None

    def __post_init__(self):
        if self.points is None:
            self.points = float(self.max_points) if self.passed else 0.0

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "points": self.points,
            "max_points": self.max_points,
            "passed": self.passed,
            "expected": self.expected,
            "actual": self.actual,
            "hint": self.hint,
        }


@dataclass
class Report:
    """一天的完整评分结果。"""

    day: str
    checks: List[CheckResult] = field(default_factory=list)

    def add(self, result: CheckResult) -> None:
        self.checks.append(result)

    def total(self) -> float:
        return sum(c.points for c in self.checks)

    def max_total(self) -> float:
        return sum(c.max_points for c in self.checks)

    def render_terminal(self, color: bool = True) -> str:
        g, r, y, d, z = (_GREEN, _RED, _YELLOW, _DIM, _RESET) if color else ("",) * 5
        lines = [f"===== {self.day} 评分结果 ====="]
        for c in self.checks:
            mark = f"{g}[通过]{z}" if c.passed else f"{r}[未通过]{z}"
            lines.append(f"{mark} {c.name}  ({c.points:g}/{c.max_points:g} 分)")
            # 通过的项不展开细节，避免刷屏淹没真正要看的失败项
            if not c.passed:
                lines.append(f"    {d}期望：{z}{c.expected}")
                lines.append(f"    {d}实际：{z}{c.actual}")
                if c.hint:
                    lines.append(f"    {y}建议：{z}{c.hint}")
        lines.append("-" * 34)
        lines.append(f"总分：{self.total():g} / {self.max_total():g}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "day": self.day,
            "total": self.total(),
            "max_total": self.max_total(),
            "checks": [c.to_dict() for c in self.checks],
        }

    def save_json(self, path: str) -> None:
        """存成 JSON 供教师汇总全班成绩。中文不转义，人要能直接读。"""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
