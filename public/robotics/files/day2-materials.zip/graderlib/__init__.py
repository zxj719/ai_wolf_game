"""考核评分公共库。

模块划分：
    report.py  计分与报告输出（不依赖 rclpy）
    urdf.py    URDF 解析、TF 树、惯量校验（不依赖 rclpy）
    probe.py   ROS2 运行时内省（需要 rclpy）
    checks.py  断言 DSL，产出 CheckResult（需要 rclpy）

report 与 urdf 可在任意机器上单测；probe 与 checks 需要装有 ROS2 Humble 的环境。
"""
