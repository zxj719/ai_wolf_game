"""URDF 解析与物理属性校验。

不依赖 rclpy 与 ROS2，可在任意机器上单测。Day 4 的自检与 Day 5 的 L1 评分都用它。

只解析评分需要的部分：link 的 inertial（质量与惯量矩阵）、joint 的父子关系与
origin/axis。visual 与 collision 的几何体不解析——考卷要求的是学员自己按公式
算出惯量，而不是我们替他从几何体反推。
"""
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from typing import Dict, List, Tuple

Vec3 = Tuple[float, float, float]
INERTIA_KEYS = ("ixx", "iyy", "izz", "ixy", "ixz", "iyz")


def close_enough(actual: float, expected: float, rel_tol: float = 0.01) -> bool:
    """相对误差比较，默认容差 1%。

    expected 为 0 时相对误差无意义，退化为绝对误差 1e-9。
    """
    if expected == 0.0:
        return abs(actual) < 1e-9
    return abs(actual - expected) / abs(expected) <= rel_tol


def box_inertia(mass: float, x: float, y: float, z: float) -> Dict[str, float]:
    """长方体绕质心的转动惯量。x/y/z 为三边长。"""
    return {
        "ixx": mass / 12.0 * (y * y + z * z),
        "iyy": mass / 12.0 * (x * x + z * z),
        "izz": mass / 12.0 * (x * x + y * y),
        "ixy": 0.0, "ixz": 0.0, "iyz": 0.0,
    }


def cylinder_inertia(mass: float, radius: float, length: float) -> Dict[str, float]:
    """圆柱绕质心的转动惯量，自身轴为 z 轴。

    注意 izz（绕自身轴）与 ixx/iyy（绕径向）不同，这是学员最常写错的地方。
    """
    ixx = 1.0 / 12.0 * mass * (3.0 * radius * radius + length * length)
    return {
        "ixx": ixx, "iyy": ixx,
        "izz": 0.5 * mass * radius * radius,
        "ixy": 0.0, "ixz": 0.0, "iyz": 0.0,
    }


def sphere_inertia(mass: float, radius: float) -> Dict[str, float]:
    """实心球绕质心的转动惯量，三轴相等。"""
    i = 2.0 / 5.0 * mass * radius * radius
    return {"ixx": i, "iyy": i, "izz": i, "ixy": 0.0, "ixz": 0.0, "iyz": 0.0}


def _parse_vec3(text: str) -> Vec3:
    parts = [float(v) for v in text.split()]
    return (parts[0], parts[1], parts[2])


def _origin_of(elem) -> Tuple[Vec3, Vec3]:
    """读取子元素 <origin>，缺省为全零（URDF 规范的默认值）。"""
    o = elem.find("origin")
    if o is None:
        return (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)
    return _parse_vec3(o.get("xyz", "0 0 0")), _parse_vec3(o.get("rpy", "0 0 0"))


@dataclass
class Link:
    name: str
    mass: float = 0.0
    inertia: Dict[str, float] = field(default_factory=dict)
    origin_xyz: Vec3 = (0.0, 0.0, 0.0)
    origin_rpy: Vec3 = (0.0, 0.0, 0.0)
    has_inertial: bool = False


@dataclass
class Joint:
    name: str
    jtype: str
    parent: str
    child: str
    origin_xyz: Vec3 = (0.0, 0.0, 0.0)
    origin_rpy: Vec3 = (0.0, 0.0, 0.0)
    axis: Vec3 = (1.0, 0.0, 0.0)


@dataclass
class RobotModel:
    name: str
    links: Dict[str, Link] = field(default_factory=dict)
    joints: Dict[str, Joint] = field(default_factory=dict)

    def _roots(self) -> List[str]:
        """没有作为任何 joint 的 child 出现过的 link 就是根。"""
        children = {j.child for j in self.joints.values()}
        return sorted(n for n in self.links if n not in children)

    def root(self) -> str:
        roots = self._roots()
        if len(roots) != 1:
            raise ValueError(
                f"期望恰好一个根 link，实际找到 {len(roots)} 个：{roots}。"
                "多个根意味着模型被拆成了互不相连的几棵树。"
            )
        return roots[0]

    def tf_tree(self) -> Dict[str, List[str]]:
        """父 link -> 子 link 列表。"""
        tree: Dict[str, List[str]] = {n: [] for n in self.links}
        for j in self.joints.values():
            tree.setdefault(j.parent, []).append(j.child)
        return tree

    def is_connected(self) -> Tuple[bool, List[str]]:
        """从根出发 BFS，返回 (是否全连通, 孤立 link 名列表)。

        有多个根时从字典序最小的那个出发，其余会被报为孤立——这正是我们想要的
        提示：学员会看到哪些 link 没连上主干。
        """
        roots = self._roots()
        if not roots:
            # 每个 link 都是某个 joint 的 child，说明存在环
            return False, sorted(self.links)
        start = roots[0]
        tree = self.tf_tree()
        seen, queue = {start}, [start]
        while queue:
            cur = queue.pop(0)
            for nxt in tree.get(cur, []):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        orphans = sorted(set(self.links) - seen)
        return (not orphans), orphans


def parse_urdf(xml_text: str) -> RobotModel:
    """把 URDF 文本解析成 RobotModel。xacro 需先展开再传进来。"""
    root_el = ET.fromstring(xml_text)
    model = RobotModel(name=root_el.get("name", ""))

    for le in root_el.findall("link"):
        link = Link(name=le.get("name"))
        inertial = le.find("inertial")
        if inertial is not None:
            link.has_inertial = True
            mass_el = inertial.find("mass")
            if mass_el is not None:
                link.mass = float(mass_el.get("value", "0"))
            inr_el = inertial.find("inertia")
            if inr_el is not None:
                link.inertia = {k: float(inr_el.get(k, "0")) for k in INERTIA_KEYS}
            link.origin_xyz, link.origin_rpy = _origin_of(inertial)
        model.links[link.name] = link

    for je in root_el.findall("joint"):
        parent_el, child_el = je.find("parent"), je.find("child")
        joint = Joint(
            name=je.get("name"),
            jtype=je.get("type", ""),
            parent=parent_el.get("link") if parent_el is not None else "",
            child=child_el.get("link") if child_el is not None else "",
        )
        joint.origin_xyz, joint.origin_rpy = _origin_of(je)
        axis_el = je.find("axis")
        if axis_el is not None:
            joint.axis = _parse_vec3(axis_el.get("xyz", "1 0 0"))
        model.joints[joint.name] = joint

    return model
