"""Day 4/5 共用的机器人模型检查。

Day 4 的自检和 Day 5 的评分查的是同一批东西，只是分值不同，
所以把判定逻辑集中在这里，两个脚本只做声明。
"""
import os
import subprocess
from typing import Dict, List, Optional, Tuple

from .report import CheckResult
from .urdf import (RobotModel, box_inertia, close_enough, cylinder_inertia,
                   parse_urdf, sphere_inertia)


def expand_xacro(path: str) -> str:
    """把 xacro 展开成 URDF。失败时把 xacro 自己的报错原样带出来。"""
    if not os.path.exists(path):
        raise FileNotFoundError(f'找不到文件：{path}')
    r = subprocess.run(['xacro', path], capture_output=True, text=True, timeout=90)
    if r.returncode != 0:
        raise RuntimeError((r.stderr or r.stdout).strip()[:600] or 'xacro 展开失败')
    return r.stdout


def check_xacro_expands(path: str, max_points: float) -> Tuple[CheckResult, Optional[RobotModel]]:
    try:
        model = parse_urdf(expand_xacro(path))
    except Exception as e:                      # noqa: BLE001 一切失败都要变成可读输出
        return CheckResult(
            name='xacro 能展开为合法 URDF', max_points=max_points, passed=False,
            expected=f'xacro {path} 输出可解析的 URDF',
            actual=str(e),
            hint='先在终端手动跑 xacro <文件> 看报错；'
                 '常见原因是括号不配对、属性名拼错、宏的参数个数不对'), None
    return CheckResult(
        name='xacro 能展开为合法 URDF', max_points=max_points, passed=True,
        expected='可解析', actual=f'解析出 {len(model.links)} 个 link、'
                                  f'{len(model.joints)} 个 joint'), model


def check_links_present(model: RobotModel, required: List[str],
                        max_points: float) -> CheckResult:
    missing = [n for n in required if n not in model.links]
    return CheckResult(
        name='约定的 link 齐全', max_points=max_points, passed=not missing,
        expected=f'包含 {required}',
        actual='齐全' if not missing else f'缺少 {missing}；实际有 {sorted(model.links)}',
        hint='link 名必须与考卷完全一致，评分脚本按名字查找')


def check_tree_connected(model: RobotModel, root: str,
                         max_points: float) -> CheckResult:
    ok, orphans = model.is_connected()
    try:
        actual_root = model.root()
    except ValueError as e:
        return CheckResult(
            name='TF 树单根且全连通', max_points=max_points, passed=False,
            expected=f'唯一根节点 {root}，无孤立 link', actual=str(e),
            hint='每个 link 都要有一个 joint 把它连到父 link 上；'
                 '出现多个根说明有 link 没连上')
    passed = ok and actual_root == root
    detail = []
    if actual_root != root:
        detail.append(f'根是 {actual_root} 而不是 {root}')
    if orphans:
        detail.append(f'孤立 link：{orphans}')
    return CheckResult(
        name='TF 树单根且全连通', max_points=max_points, passed=passed,
        expected=f'唯一根节点 {root}，无孤立 link',
        actual='正常' if passed else '；'.join(detail),
        hint='用 check_urdf 展开后的文件可以看到同样的结论')


def check_joints(model: RobotModel, spec: Dict[str, dict],
                 max_points: float) -> CheckResult:
    """spec: {joint 名: {'type':..., 'parent':..., 'child':..., 'axis':(可选)}}"""
    bad = []
    for name, want in spec.items():
        j = model.joints.get(name)
        if j is None:
            bad.append(f'{name}(不存在)')
            continue
        if j.jtype != want['type']:
            bad.append(f"{name}.type={j.jtype}(应为{want['type']})")
        if j.parent != want['parent']:
            bad.append(f"{name}.parent={j.parent}(应为{want['parent']})")
        if j.child != want['child']:
            bad.append(f"{name}.child={j.child}(应为{want['child']})")
        if 'axis' in want and tuple(j.axis) != tuple(want['axis']):
            bad.append(f"{name}.axis={j.axis}(应为{want['axis']})")
    return CheckResult(
        name='关节的类型与父子关系正确', max_points=max_points, passed=not bad,
        expected='见考卷的关节表',
        actual='全部正确' if not bad else '；'.join(bad[:6]),
        hint='驱动轮是 continuous 且绕 y 轴（axis 0 1 0）；'
             '传感器和万向轮是 fixed')


def check_masses(model: RobotModel, expected: Dict[str, float],
                 max_points: float) -> CheckResult:
    bad = []
    for name, m in expected.items():
        link = model.links.get(name)
        if link is None:
            bad.append(f'{name}(link 不存在)')
        elif not link.has_inertial:
            bad.append(f'{name}(没有 inertial 段)')
        elif not close_enough(link.mass, m):
            bad.append(f'{name}={link.mass:g}(应为{m:g})')
    return CheckResult(
        name='各 link 质量与题面一致', max_points=max_points, passed=not bad,
        expected=str(expected),
        actual='全部正确' if not bad else '；'.join(bad),
        hint='质量写在 <inertial><mass value="..."/>')


def check_inertias(model: RobotModel, expected: Dict[str, Dict[str, float]],
                   max_points: float) -> CheckResult:
    """expected 由 box_inertia / cylinder_inertia / sphere_inertia 算出。"""
    bad = []
    for name, want in expected.items():
        link = model.links.get(name)
        if link is None or not link.inertia:
            bad.append(f'{name}(缺 inertia)')
            continue
        for key in ('ixx', 'iyy', 'izz'):
            got = link.inertia.get(key, 0.0)
            if not close_enough(got, want[key]):
                bad.append(f'{name}.{key}={got:.6g}(应为{want[key]:.6g})')
    return CheckResult(
        name='惯量矩阵与公式计算一致', max_points=max_points, passed=not bad,
        expected='按考卷给出的三个公式代入计算',
        actual='全部正确' if not bad else '；'.join(bad[:6]),
        hint='圆柱的 izz 只跟半径有关（m·r²/2），'
             'ixx/iyy 还跟长度有关——轮子最容易在这里写错')


def check_joint_origin(model: RobotModel, joint: str, axis_idx: int,
                       expected_value: float, desc: str,
                       max_points: float) -> CheckResult:
    j = model.joints.get(joint)
    axis_name = 'xyz'[axis_idx]
    if j is None:
        return CheckResult(
            name=f'{joint} 的安装位置正确', max_points=max_points, passed=False,
            expected=desc, actual=f'关节 {joint} 不存在',
            hint='关节名要与考卷一致')
    got = j.origin_xyz[axis_idx]
    ok = close_enough(got, expected_value)
    return CheckResult(
        name=f'{joint} 的安装位置正确', max_points=max_points, passed=ok,
        expected=desc,
        actual=f'origin 的 {axis_name} = {got:g}（应为 {expected_value:g}）',
        hint='origin 是子 link 相对父 link 的位置，单位是米')


__all__ = [
    'expand_xacro', 'check_xacro_expands', 'check_links_present',
    'check_tree_connected', 'check_joints', 'check_masses', 'check_inertias',
    'check_joint_origin', 'box_inertia', 'cylinder_inertia', 'sphere_inertia',
]
