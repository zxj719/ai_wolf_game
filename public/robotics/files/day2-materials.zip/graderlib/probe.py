"""ROS2 运行时内省。

仅在装有 ROS2 Humble 的机器上可用（需要 rclpy）。评分脚本用它来观察学员启动的
节点：有哪些节点、哪些话题、类型对不对、频率多少、消息内容是什么。

用法：

    with Probe() as p:
        print(p.topic_types())
"""
import time
from typing import Dict, List, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, HistoryPolicy, QoSProfile, ReliabilityPolicy
from rosidl_runtime_py.utilities import get_message


def _permissive_qos(depth: int = 10) -> QoSProfile:
    """尽量能收到各种发布者的 QoS。

    BEST_EFFORT 订阅者可以接收 RELIABLE 发布者的消息，反过来不行。评分脚本要能
    观察到学员的任何合法实现，所以订阅端一律用最宽松的一侧。
    """
    return QoSProfile(
        reliability=ReliabilityPolicy.BEST_EFFORT,
        history=HistoryPolicy.KEEP_LAST,
        depth=depth,
        durability=DurabilityPolicy.VOLATILE,
    )


class Probe:
    """内省用的隐藏节点，进入上下文时等待 DDS 发现完成。"""

    def __init__(self, node_name: str = "grader_probe", discovery_wait: float = 2.0):
        self._node_name = node_name
        self._discovery_wait = discovery_wait
        self._node: Optional[Node] = None
        self._owns_context = False

    def __enter__(self) -> "Probe":
        if not rclpy.ok():
            rclpy.init()
            self._owns_context = True
        self._node = rclpy.create_node(self._node_name)
        # DDS 发现需要时间。过早内省会漏掉刚启动的节点与话题，
        # 表现为"明明起了却查不到"，是最容易误判的地方。
        time.sleep(self._discovery_wait)
        return self

    def __exit__(self, *exc):
        if self._node is not None:
            self._node.destroy_node()
        if self._owns_context and rclpy.ok():
            rclpy.shutdown()
        return False

    def node_names(self) -> List[str]:
        """返回带 namespace 的完整节点名，如 /day2/talker。"""
        out = []
        for name, ns in self._node.get_node_names_and_namespaces():
            out.append(name if ns in ("/", "") else f"{ns.rstrip('/')}/{name}")
        return out

    def topic_types(self) -> Dict[str, List[str]]:
        """话题名 -> 类型字符串列表。"""
        return dict(self._node.get_topic_names_and_types())

    def wait_for_topic(self, topic: str, timeout: float = 8.0) -> Dict[str, List[str]]:
        """轮询直到话题出现或超时，返回最后一次看到的话题表。

        单次 get_topic_names_and_types() 不可靠：DDS 图的传播是渐进的，
        刚启动的节点可能要几秒才被看到。不轮询就会把正确的作业判成错的——
        这比漏判更糟，学员会去改本来没问题的代码。
        """
        deadline = time.time() + timeout
        types = self.topic_types()
        while topic not in types and time.time() < deadline:
            rclpy.spin_once(self._node, timeout_sec=0.2)
            types = self.topic_types()
        return types

    def wait_for_node(self, node_name: str, timeout: float = 8.0) -> List[str]:
        """轮询直到节点出现或超时，返回最后一次看到的节点列表。"""
        target = node_name.lstrip("/")

        def hit(names):
            return any(n == node_name or n.lstrip("/") == target
                       or n.endswith("/" + target) for n in names)

        deadline = time.time() + timeout
        names = self.node_names()
        while not hit(names) and time.time() < deadline:
            rclpy.spin_once(self._node, timeout_sec=0.2)
            names = self.node_names()
        return names

    def publisher_count(self, topic: str) -> int:
        return self._node.count_publishers(topic)

    def subscriber_count(self, topic: str) -> int:
        return self._node.count_subscribers(topic)

    def sample(self, topic: str, type_str: str, timeout: float = 5.0):
        """收到第一条消息就返回，超时返回 None。"""
        msg_cls = get_message(type_str)
        box = {"msg": None}

        def _cb(m):
            if box["msg"] is None:
                box["msg"] = m

        sub = self._node.create_subscription(msg_cls, topic, _cb, _permissive_qos())
        deadline = time.time() + timeout
        try:
            while time.time() < deadline and box["msg"] is None:
                rclpy.spin_once(self._node, timeout_sec=0.1)
        finally:
            self._node.destroy_subscription(sub)
        return box["msg"]

    def measure_hz(self, topic: str, type_str: str, duration: float = 3.0) -> float:
        """统计 duration 秒内的到达频率；收到少于 2 条返回 0.0。

        用首尾时间戳之差而非 duration 作分母，避免把订阅建立前的空窗算进去。
        """
        msg_cls = get_message(type_str)
        stamps: List[float] = []

        def _cb(_m):
            stamps.append(time.time())

        sub = self._node.create_subscription(msg_cls, topic, _cb, _permissive_qos(depth=200))
        deadline = time.time() + duration
        try:
            while time.time() < deadline:
                rclpy.spin_once(self._node, timeout_sec=0.05)
        finally:
            self._node.destroy_subscription(sub)
        if len(stamps) < 2:
            return 0.0
        span = stamps[-1] - stamps[0]
        return (len(stamps) - 1) / span if span > 0 else 0.0

    def collect(self, topic: str, type_str: str, duration: float = 3.0) -> List:
        """收集一段时间内该话题上的所有消息。"""
        msg_cls = get_message(type_str)
        got: List = []
        sub = self._node.create_subscription(
            msg_cls, topic, got.append, _permissive_qos(depth=200))
        deadline = time.time() + duration
        try:
            while time.time() < deadline:
                rclpy.spin_once(self._node, timeout_sec=0.05)
        finally:
            self._node.destroy_subscription(sub)
        return got

    def publish_burst(self, topic: str, type_str: str, msg, count: int, hz: float) -> None:
        """主动发一串消息，用于验证学员的 Subscriber 是否真的在工作。"""
        msg_cls = get_message(type_str)
        pub = self._node.create_publisher(msg_cls, topic, 10)
        period = 1.0 / hz
        try:
            for _ in range(count):
                pub.publish(msg)
                end = time.time() + period
                while time.time() < end:
                    rclpy.spin_once(self._node, timeout_sec=0.01)
        finally:
            self._node.destroy_publisher(pub)

    def publish_and_collect(self, pub_topic: str, pub_type: str, pub_msg,
                            sub_topic: str, sub_type: str,
                            count: int = 10, hz: float = 20.0) -> List:
        """一边向 pub_topic 注入消息，一边收集 sub_topic 上的输出。

        用于验证"学员的节点确实在处理输入并产生对应输出"。比分别采样两个话题
        再比数值可靠得多——学员的话题上通常还有他自己的数据在流动，分别采样
        拿到的两个值本来就不对应同一次处理。

        做法是注入一个不可能自然出现的哨兵值，再在输出里找它对应的结果。
        """
        pub_cls, sub_cls = get_message(pub_type), get_message(sub_type)
        got: List = []
        sub = self._node.create_subscription(
            sub_cls, sub_topic, got.append, _permissive_qos(depth=200))
        pub = self._node.create_publisher(pub_cls, pub_topic, 10)
        period = 1.0 / hz
        try:
            # 先让订阅建立起来，否则前几条输出会丢
            settle = time.time() + 0.5
            while time.time() < settle:
                rclpy.spin_once(self._node, timeout_sec=0.05)
            for _ in range(count):
                pub.publish(pub_msg)
                end = time.time() + period
                while time.time() < end:
                    rclpy.spin_once(self._node, timeout_sec=0.01)
            # 留出处理与回传的时间
            drain = time.time() + 0.5
            while time.time() < drain:
                rclpy.spin_once(self._node, timeout_sec=0.05)
        finally:
            self._node.destroy_publisher(pub)
            self._node.destroy_subscription(sub)
        return got
