"""断言 DSL：把 Probe 的观测结果包装成 CheckResult。

每个 check 的失败信息都必须可操作——学员是自学的，没人可问。所以 actual 字段
要给出真实观测到的东西（比如当前所有话题列表），而不只是"没找到"。
"""
from typing import Callable

from .probe import Probe
from .report import CheckResult


def check_node_running(probe: Probe, node_name: str, max_points: float,
                       hint: str = "") -> CheckResult:
    # 轮询等待而不是只看一眼：DDS 发现是渐进的，看一眼会误判正确的作业
    names = probe.wait_for_node(node_name)
    target = node_name.lstrip("/")
    hit = any(n == node_name or n.lstrip("/") == target or n.endswith("/" + target)
              for n in names)
    return CheckResult(
        name=f"节点 {node_name} 正在运行",
        max_points=max_points, passed=hit,
        expected=f"节点列表中存在 {node_name}",
        actual="已找到" if hit else f"当前节点列表：{sorted(names)}",
        hint=hint or "确认已在另一个终端启动该节点，且已 source install/setup.bash",
    )


def check_topic_exists(probe: Probe, topic: str, type_str: str, max_points: float,
                       hint: str = "") -> CheckResult:
    types = probe.wait_for_topic(topic)
    if topic not in types:
        return CheckResult(
            name=f"话题 {topic} 存在", max_points=max_points, passed=False,
            expected=f"存在话题 {topic}（类型 {type_str}）",
            actual=f"未找到该话题。当前话题：{sorted(types)}",
            hint=hint or "检查话题名拼写，注意 namespace 前缀",
        )
    ok = type_str in types[topic]
    return CheckResult(
        name=f"话题 {topic} 存在且类型正确", max_points=max_points, passed=ok,
        expected=f"{topic} 的类型为 {type_str}",
        actual=f"{topic} 的实际类型为 {types[topic]}",
        hint=hint or "用 ros2 topic info <话题> 查看类型",
    )


def check_topic_hz(probe: Probe, topic: str, type_str: str, lo: float, hi: float,
                   max_points: float, hint: str = "") -> CheckResult:
    # 先等话题被发现，否则测量窗口会被发现过程吃掉一大截，测出偏低的频率
    probe.wait_for_topic(topic)
    hz = probe.measure_hz(topic, type_str)
    ok = lo <= hz <= hi
    detail = "（一条消息都没收到）" if hz == 0.0 else ""
    return CheckResult(
        name=f"话题 {topic} 频率在 {lo}~{hi} Hz", max_points=max_points, passed=ok,
        expected=f"{lo} Hz ≤ 频率 ≤ {hi} Hz",
        actual=f"实测 {hz:.2f} Hz{detail}",
        hint=hint or "检查定时器周期；若为 0，可能是 QoS 不匹配或节点根本没发布",
    )


def check_message_field(probe: Probe, topic: str, type_str: str,
                        field_path: str, predicate: Callable, desc: str,
                        max_points: float, hint: str = "") -> CheckResult:
    """采样一条消息，按点号路径取字段并用 predicate 判定。

    field_path 形如 "header.frame_id"、"linear_acceleration.z"。
    """
    msg = probe.sample(topic, type_str)
    if msg is None:
        return CheckResult(
            name=f"{topic} 的 {field_path} {desc}", max_points=max_points, passed=False,
            expected=desc, actual="超时未收到任何消息",
            hint=hint or "确认发布者在运行，并检查 QoS 是否匹配",
        )
    value = msg
    for part in field_path.split("."):
        value = getattr(value, part)
    ok = bool(predicate(value))
    return CheckResult(
        name=f"{topic} 的 {field_path} {desc}", max_points=max_points, passed=ok,
        expected=desc, actual=f"实际值 {value!r}", hint=hint,
    )
